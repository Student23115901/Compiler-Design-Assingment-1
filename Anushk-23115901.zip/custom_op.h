#ifndef CUSTOM_OP_H
#define CUSTOM_OP_H

#define XVAL 1
#define YVAL 2
#define CUSTOM_OP 3

extern double xVal, yVal;

#endif
