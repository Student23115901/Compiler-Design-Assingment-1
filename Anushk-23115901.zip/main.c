#include <stdio.h>

void computeExpression();

int main() {
    printf("Enter expression like: x3 y4 custom_operation\n> ");
    computeExpression();
    return 0;
}
